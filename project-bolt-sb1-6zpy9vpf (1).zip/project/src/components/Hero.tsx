import React from 'react';

const Hero: React.FC = () => {
  return (
    <section className="pt-24 md:pt-32 pb-16 bg-gradient-to-b from-amber-400 via-amber-300 to-amber-100">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 text-center md:text-left mb-8 md:mb-0">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-800 mb-4 animate-fade-in">
              সাতক্ষীরা আমওয়ালা
            </h1>
            <p className="text-xl md:text-2xl text-gray-700 mb-6">
              খাঁটি সাতক্ষীরার আমের নিশ্চয়তা
            </p>
            <p className="text-gray-700 mb-8 max-w-lg mx-auto md:mx-0">
              আমরা সাতক্ষীরার খাঁটি ও রসালো আম সরাসরি বাগান থেকে আপনাদের দোরগোড়ায় পৌঁছে দেই। বাংলাদেশের সেরা আম এখন আপনার নাগালে।
            </p>
            <div className="flex flex-col sm:flex-row justify-center md:justify-start space-y-4 sm:space-y-0 sm:space-x-4">
              <a 
                href="#products" 
                className="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg font-medium transition-colors duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
              >
                আমের ধরন দেখুন
              </a>
              <a 
                href="#order" 
                className="bg-white hover:bg-gray-100 text-green-700 border-2 border-green-600 px-6 py-3 rounded-lg font-medium transition-colors duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
              >
                অর্ডার করুন
              </a>
            </div>
          </div>
          <div className="md:w-1/2 flex justify-center">
            <div className="relative">
              <div className="absolute -inset-4 md:-inset-6 rounded-full bg-amber-500 opacity-20 animate-pulse"></div>
              <img 
                src="https://images.pexels.com/photos/918643/pexels-photo-918643.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" 
                alt="সাতক্ষীরার আম" 
                className="rounded-3xl shadow-2xl w-full max-w-md object-cover transform hover:scale-105 transition-transform duration-500"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;