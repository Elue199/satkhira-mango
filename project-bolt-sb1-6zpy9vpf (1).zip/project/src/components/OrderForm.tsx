import React, { useState } from 'react';

interface FormData {
  name: string;
  address: string;
  phone: string;
  product: string;
  quantity: string;
  details: string;
}

const OrderForm: React.FC = () => {
  const [formData, setFormData] = useState<FormData>({
    name: '',
    address: '',
    phone: '',
    product: 'হিমসাগর',
    quantity: '১০ কেজি',
    details: ''
  });
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitted(true);
      
      // Reset form after showing success message
      setTimeout(() => {
        setSubmitted(false);
        setFormData({
          name: '',
          address: '',
          phone: '',
          product: 'হিমসাগর',
          quantity: '১০ কেজি',
          details: ''
        });
      }, 3000);
    }, 1500);
  };

  return (
    <section id="order" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center text-gray-800 mb-12 relative">
          অর্ডার করুন
          <span className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-24 h-1 bg-amber-400 mt-2"></span>
        </h2>
        
        <div className="max-w-2xl mx-auto bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="bg-amber-400 py-4 px-6">
            <h3 className="text-xl font-bold text-gray-800">আপনার পছন্দের আম অর্ডার করুন</h3>
            <p className="text-gray-700">আমরা ৭২ ঘন্টার মধ্যে সারা দেশে ডেলিভারি করি</p>
          </div>
          
          <div className="p-6">
            {submitted ? (
              <div className="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4 rounded">
                <p className="font-medium">আপনার অর্ডার সফলভাবে জমা হয়েছে!</p>
                <p>আমরা শীঘ্রই আপনার সাথে যোগাযোগ করব।</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <label htmlFor="name" className="block text-gray-700 mb-1">আপনার নাম</label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-400 focus:border-transparent transition-colors duration-200"
                      required
                    />
                  </div>
                  <div>
                    <label htmlFor="phone" className="block text-gray-700 mb-1">মোবাইল নাম্বার</label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-400 focus:border-transparent transition-colors duration-200"
                      required
                    />
                  </div>
                </div>
                
                <div className="mb-4">
                  <label htmlFor="address" className="block text-gray-700 mb-1">আপনার ঠিকানা</label>
                  <input
                    type="text"
                    id="address"
                    name="address"
                    value={formData.address}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-400 focus:border-transparent transition-colors duration-200"
                    required
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <label htmlFor="product" className="block text-gray-700 mb-1">আমের ধরন</label>
                    <select
                      id="product"
                      name="product"
                      value={formData.product}
                      onChange={handleChange}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-400 focus:border-transparent transition-colors duration-200"
                      required
                    >
                      <option value="হিমসাগর">হিমসাগর</option>
                      <option value="ল্যাংড়া">ল্যাংড়া</option>
                      <option value="আম্রপালি">আম্রপালি</option>
                      <option value="গোবিন্দভোগ">গোবিন্দভোগ</option>
                    </select>
                  </div>
                  <div>
                    <label htmlFor="quantity" className="block text-gray-700 mb-1">পরিমাণ</label>
                    <select
                      id="quantity"
                      name="quantity"
                      value={formData.quantity}
                      onChange={handleChange}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-400 focus:border-transparent transition-colors duration-200"
                      required
                    >
                      <option value="৫ কেজি">৫ কেজি</option>
                      <option value="১০ কেজি">১০ কেজি</option>
                      <option value="১৫ কেজি">১৫ কেজি</option>
                      <option value="২০ কেজি">২০ কেজি</option>
                    </select>
                  </div>
                </div>
                
                <div className="mb-6">
                  <label htmlFor="details" className="block text-gray-700 mb-1">অতিরিক্ত তথ্য (যদি থাকে)</label>
                  <textarea
                    id="details"
                    name="details"
                    value={formData.details}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-400 focus:border-transparent transition-colors duration-200"
                    rows={3}
                  />
                </div>
                
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className={`w-full bg-green-600 hover:bg-green-700 text-white font-medium py-3 rounded-lg transition-colors duration-300 ${isSubmitting ? 'opacity-75 cursor-not-allowed' : ''}`}
                >
                  {isSubmitting ? 'অর্ডার প্রক্রিয়াধীন...' : 'অর্ডার করুন'}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default OrderForm;