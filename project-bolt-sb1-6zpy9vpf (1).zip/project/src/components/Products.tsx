import React from 'react';

interface Product {
  id: number;
  name: string;
  description: string;
  image: string;
  features: string[];
}

const Products: React.FC = () => {
  const products: Product[] = [
    {
      id: 1,
      name: 'হিমসাগর',
      description: 'রসালো, মিষ্টি, আঁশহীন আম। সাতক্ষীরার বিশেষ আম।',
      image: 'https://upload.wikimedia.org/wikipedia/commons/5/5b/Himsagar_Mango.jpg',
      features: ['মধুর মিষ্টি স্বাদ', 'ক্রিমি টেক্সচার', 'আঁশহীন', 'হলুদ-কমলা রঙ']
    },
    {
      id: 2,
      name: 'ল্যাংড়া',
      description: 'চাহিদাসম্পন্ন স্বাদযুক্ত আম। এর সুগন্ধ ও মিষ্টতা অতুলনীয়।',
      image: 'https://upload.wikimedia.org/wikipedia/commons/6/6b/Langra_Mango.jpg',
      features: ['সবুজাভ হলুদ রঙ', 'অতুলনীয় সুগন্ধ', 'মিষ্টি স্বাদ', 'ঘন রস']
    },
    {
      id: 3,
      name: 'আম্রপালি',
      description: 'বড় আকার, মিষ্টি স্বাদ। উচ্চ পুষ্টিমান সমৃদ্ধ আম।',
      image: 'https://upload.wikimedia.org/wikipedia/commons/e/e4/Fazli_Mango.jpg',
      features: ['গাঢ় লাল-হলুদ রঙ', 'ফাইবার কম', 'উচ্চ পুষ্টিমান', 'মাঝারি মিষ্টি']
    },
    {
      id: 4,
      name: 'গোবিন্দভোগ',
      description: 'সাধারণত দ্রুত বিক্রি হয়ে যায়। খুব জনপ্রিয় আম।',
      image: 'https://upload.wikimedia.org/wikipedia/commons/0/0b/Langra_mango_in_Bihar.jpg',
      features: ['হালকা সুগন্ধ', 'ভরপুর রস', 'আঁশহীন', 'সোনালি রঙ']
    }
  ];

  return (
    <section id="products" className="py-16 bg-amber-50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center text-gray-800 mb-12 relative">
          আমের ধরন
          <span className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-24 h-1 bg-amber-400 mt-2"></span>
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {products.map((product) => (
            <div 
              key={product.id} 
              className="bg-white rounded-xl shadow-lg overflow-hidden transform hover:-translate-y-2 transition-transform duration-300"
            >
              <div className="relative overflow-hidden h-48">
                <img 
                  src={product.image} 
                  alt={product.name} 
                  className="w-full h-full object-cover transform hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 hover:opacity-100 transition-opacity duration-300 flex items-end">
                  <div className="p-4 text-white">
                    <p className="font-medium">{product.description}</p>
                  </div>
                </div>
              </div>
              <div className="p-4">
                <h3 className="text-xl font-bold text-gray-800 mb-2">{product.name}</h3>
                <p className="text-gray-600 mb-4">{product.description}</p>
                <ul className="space-y-1">
                  {product.features.map((feature, index) => (
                    <li key={index} className="flex items-center text-sm">
                      <span className="inline-block w-2 h-2 bg-green-500 rounded-full mr-2"></span>
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Products;