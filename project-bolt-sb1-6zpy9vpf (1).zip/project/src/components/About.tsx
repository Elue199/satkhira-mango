import React from 'react';

const About: React.FC = () => {
  return (
    <section id="about" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-8 md:mb-0">
            <img 
              src="https://images.pexels.com/photos/2363347/pexels-photo-2363347.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" 
              alt="মাঙ্গো বাগান" 
              className="rounded-lg shadow-xl"
            />
          </div>
          <div className="md:w-1/2 md:pl-12">
            <h2 className="text-3xl font-bold text-gray-800 mb-6 inline-block relative">
              আমাদের সম্পর্কে
              <span className="absolute bottom-0 left-0 w-1/2 h-1 bg-amber-400"></span>
            </h2>
            <p className="text-gray-700 mb-4">
              সাতক্ষীরার আমের খ্যাতি বাংলাদেশে সর্বজনবিদিত। বিশেষ করে হিমসাগর, ল্যাংড়া, আম্রপালি ও গোবিন্দভোগ জাতের আম এই অঞ্চলে প্রচুর পরিমাণে উৎপাদিত হয়।
            </p>
            <p className="text-gray-700 mb-6">
              আমরা সাতক্ষীরার খাঁটি ও রসালো আম সরাসরি বাগান থেকে আপনাদের দোরগোড়ায় পৌঁছে দেই। আমাদের লক্ষ্য হল গ্রাহকদের উচ্চমানের, টাটকা ও স্বাস্থ্যকর আম সরবরাহ করা।
            </p>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-amber-100 rounded-lg p-4 shadow-md transform hover:scale-105 transition-transform duration-300">
                <h3 className="font-semibold text-gray-800 mb-2">টাটকা আম</h3>
                <p className="text-sm text-gray-600">সরাসরি বাগান থেকে সংগ্রহ করা আম</p>
              </div>
              <div className="bg-amber-100 rounded-lg p-4 shadow-md transform hover:scale-105 transition-transform duration-300">
                <h3 className="font-semibold text-gray-800 mb-2">দ্রুত ডেলিভারি</h3>
                <p className="text-sm text-gray-600">৭২ ঘন্টার মধ্যে সারা দেশে</p>
              </div>
              <div className="bg-amber-100 rounded-lg p-4 shadow-md transform hover:scale-105 transition-transform duration-300">
                <h3 className="font-semibold text-gray-800 mb-2">উন্নত প্যাকেজিং</h3>
                <p className="text-sm text-gray-600">নিরাপদ ও শক্তিশালী প্যাকেজিং</p>
              </div>
              <div className="bg-amber-100 rounded-lg p-4 shadow-md transform hover:scale-105 transition-transform duration-300">
                <h3 className="font-semibold text-gray-800 mb-2">সন্তুষ্টি গ্যারান্টি</h3>
                <p className="text-sm text-gray-600">১০০% সন্তুষ্টি নিশ্চিত</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;