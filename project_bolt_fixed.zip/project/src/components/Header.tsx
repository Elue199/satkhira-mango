import React, { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';

const Header: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header 
      className={`fixed w-full z-50 transition-all duration-300 ${
        isScrolled ? 'bg-amber-300 shadow-md py-2' : 'bg-amber-400 py-4'
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <h1 className="text-2xl md:text-3xl font-bold">সাতক্ষীরা আমওয়ালা</h1>
          </div>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            {['আমাদের সম্পর্কে', 'আমের ধরন', 'দাম', 'রিভিউ', 'অর্ডার', 'যোগাযোগ'].map((item, index) => (
              <a 
                key={index}
                href={`#${['about', 'products', 'pricing', 'reviews', 'order', 'contact'][index]}`}
                className="text-gray-800 hover:text-green-700 font-medium transition-colors duration-200"
              >
                {item}
              </a>
            ))}
          </nav>
          
          {/* Mobile menu button */}
          <button 
            className="md:hidden text-gray-800 focus:outline-none"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>
      
      {/* Mobile Navigation */}
      {mobileMenuOpen && (
        <nav className="md:hidden bg-amber-200 py-4 px-4 absolute w-full">
          <div className="flex flex-col space-y-4">
            {['আমাদের সম্পর্কে', 'আমের ধরন', 'দাম', 'রিভিউ', 'অর্ডার', 'যোগাযোগ'].map((item, index) => (
              <a 
                key={index}
                href={`#${['about', 'products', 'pricing', 'reviews', 'order', 'contact'][index]}`}
                className="text-gray-800 hover:text-green-700 font-medium transition-colors duration-200 py-2 px-4 rounded-lg hover:bg-amber-100"
                onClick={() => setMobileMenuOpen(false)}
              >
                {item}
              </a>
            ))}
          </div>
        </nav>
      )}
    </header>
  );
};

export default Header;