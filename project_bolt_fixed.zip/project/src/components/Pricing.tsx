import React, { useState } from 'react';

interface Price {
  id: number;
  product: string;
  quantity: string;
  price: number;
}

const Pricing: React.FC = () => {
  const [prices] = useState<Price[]>([
    { id: 1, product: 'হিমসাগর', quantity: '১০ কেজি', price: 1200 },
    { id: 2, product: 'ল্যাংড়া', quantity: '১০ কেজি', price: 1400 },
    { id: 3, product: 'আম্রপালি', quantity: '৫ কেজি', price: 800 },
    { id: 4, product: 'গোবিন্দভোগ', quantity: '১০ কেজি', price: 1500 }
  ]);

  return (
    <section id="pricing" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center text-gray-800 mb-12 relative">
          দাম
          <span className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-24 h-1 bg-amber-400 mt-2"></span>
        </h2>
        
        <div className="max-w-3xl mx-auto bg-white rounded-xl shadow-lg overflow-hidden border border-amber-200">
          <div className="bg-amber-400 py-4 text-center">
            <h3 className="text-xl font-bold text-gray-800">আমাদের আমের মূল্য তালিকা</h3>
            <p className="text-gray-700">সাতক্ষীরার সেরা আমের দাম</p>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-amber-100">
                  <th className="py-3 px-4 text-left text-gray-800 font-semibold">প্রোডাক্ট</th>
                  <th className="py-3 px-4 text-left text-gray-800 font-semibold">পরিমাণ</th>
                  <th className="py-3 px-4 text-left text-gray-800 font-semibold">দাম</th>
                  <th className="py-3 px-4 text-left text-gray-800 font-semibold"></th>
                </tr>
              </thead>
              <tbody>
                {prices.map((item, index) => (
                  <tr 
                    key={item.id} 
                    className={`border-t border-amber-100 hover:bg-amber-50 transition-colors duration-200 ${index % 2 === 0 ? 'bg-amber-50/50' : 'bg-white'}`}
                  >
                    <td className="py-4 px-4 text-gray-700">{item.product}</td>
                    <td className="py-4 px-4 text-gray-700">{item.quantity}</td>
                    <td className="py-4 px-4 text-gray-700">৳ {item.price}</td>
                    <td className="py-4 px-4">
                      <a 
                        href="#order" 
                        className="bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded text-sm transition-colors duration-200"
                      >
                        অর্ডার
                      </a>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          
          <div className="bg-amber-100 p-4 text-center">
            <p className="text-gray-700 text-sm">
              * সমস্ত দাম বাংলাদেশের যেকোনো স্থানে ডেলিভারি চার্জসহ
            </p>
            <p className="text-gray-700 text-sm">
              * বড় অর্ডারের জন্য বিশেষ ছাড় রয়েছে
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Pricing;